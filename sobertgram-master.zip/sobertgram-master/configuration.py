from configparser import ConfigParser

Config = ConfigParser()


