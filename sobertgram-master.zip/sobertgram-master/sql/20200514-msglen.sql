ALTER TABLE `chat_uniqueness` ADD `avg_len` DOUBLE NULL AFTER `last_count_valid`;

